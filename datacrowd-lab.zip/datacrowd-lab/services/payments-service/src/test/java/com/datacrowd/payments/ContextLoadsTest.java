package com.datacrowd.payments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContextLoadsTest {
    @Test
    void contextLoads() {
    }
}
